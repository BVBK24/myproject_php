<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="CSS/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Curd Operations</title>
</head>
<body class="bg-light">
<div class="container">
        <div class="row">
            <div class="col">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2 class="text-center text-dark">Saved Records</h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <tr>
                                <td style="width: 10%">ID</td>
                                <td style="width: 20%">Firstname</td>
                                <td style="width: 20%">Lastname</td>
                                <td style="width: 20%">MailId</td>
                                <td style="width: 15%">Phone</td>
                                <td style="width: 20%" colspan="2" class="text-center">Operations</td>
                            </tr>
                            <?php $__currentLoopData = $crud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($cru->id); ?></td>
                                <td><?php echo e($cru->firstname); ?></td>
                                <td><?php echo e($cru->lastname); ?></td>
                                <td><?php echo e($cru->mail); ?></td>
                                <td><?php echo e($cru->phone); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-success" onclick="location.href='<?php echo e(route('laravelcrud.create')); ?>';">Create Record</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/show.blade.php ENDPATH**/ ?>