<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--<link rel="stylesheet" href="CSS/bootstrap.css">-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Curd Operations</title>
</head>
<body class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-header">
                        <h2>Edit Your Data</h2>
                    </div>
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('laravelcrud.update',$crud->id)); ?>">
                            
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <input type="hidden" name="id" class="form-control mb-2" placeholder="id" value="<?php echo e($crud->id); ?>" ></input>
                                <input type="text" name="firstname" class="form-control mb-2" placeholder="firstname" value="<?php echo e($crud->firstname); ?>"></input>
                                <input type="text" name="lastname" class="form-control mb-2" placeholder="lastname" value="<?php echo e($crud->lastname); ?>" ></input>
                                <input type="text" name="mail" class="form-control mb-2" placeholder="email" value="<?php echo e($crud->mail); ?>" ></input>
                                <input type="text" name="phone" class="form-control mb-2" placeholder="phone" value="<?php echo e($crud->phone); ?>" ></input>
                            
                            
                        </div>
                    <div class="card-footer">
                        <input type="submit" name="Update" value="Update" class="btn btn-success" onclick='return confirm("save the update?")'></input>
                        </form>
                        <button onclick="location.href='<?php echo e(route('read')); ?>';" value="Back" class="btn btn-success">Back</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/laravelcrud/edit.blade.php ENDPATH**/ ?>