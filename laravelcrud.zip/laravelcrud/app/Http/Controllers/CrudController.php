<?php

namespace App\Http\Controllers;

use App\Models\crud;
use Illuminate\Http\Request;

class CrudController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function read()
    {
        $crud=crud::paginate(3);
        return view('laravelcrud.read',['crud'=>$crud]);
    }
    public function index()
    {
        //$crud=crud::all();
        return view('laravelcrud.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('laravelcrud.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $record=$request->validate([
            'id'=>'required|integer',
            'firstname'=>'required',
            'lastname'=>'required',
            'mail'=>'required',
            'phone'=>'required|integer'
        ]);
        $alert=crud::create($record);
        if($alert){
            return back()->with('success','Record creted successfully');}
        else{
            return back()->with('fail','something went wrong');
        }
        //return redirect()->route('laravelcrud.show');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function show(crud $crud)
    {
        return view('show',compact('crud'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function edit($cruds)
    {
        $crud=crud::find($cruds);
        return view('laravelcrud.edit',compact('crud'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $crud)
    {
        
        $contact = crud::find($crud);
        $input = $request->all();
        $up=$contact->update($input);
        if($up){
            return redirect()->route('read')->with('upload_success','Record updated successfully');}
        else{
            return redirect()->route('read')->with('upload_fail','something went wrong');}
        /*$request->validate([
            'id'=>'required|integer',
            'firstname'=>'required',
            'lastname'=>'required',
            'mail'=>'required',
            'phone'=>'required|integer'
        ]);
        $crud->id=$request->id;
        $crud->firstname=$request->firstname;
        $crud->lastname=$request->lastname;
        $crud->mail=$request->mail;
        $crud->phone=$request->phone;
        $crud->save();
        return redirect()->route('laravelcrud.read');
        //$crud->update($request->all());*/
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\crud  $crud
     * @return \Illuminate\Http\Response
     */
    public function destroy($crud)
    {
        $del=crud::destroy($crud);
        if($del){
            return back()->with('success','Record deleted successfully');}
        else{
            return back()->with('fail','something went wrong');}
    }
    public function fetch()
    {
        return back()->with('alert','function calling');
    }
}
